package com.dts.dersliktakip.dto;

import com.dts.dersliktakip.entity.Role;

import java.util.Set;
import java.util.UUID;

public record UserResponse(
        UUID id,
        String firstName,
        String lastName,
        String fullName,
        String email,
        Set<Role> roles,
        Role role,
        String phone,
        boolean active,
        String title,
        String faculty,
        String department,
        String office
) {
}
